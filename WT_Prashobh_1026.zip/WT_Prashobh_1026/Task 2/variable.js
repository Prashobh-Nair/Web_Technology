let name = "Prashobh"; // String
let age = 20; // Number
let isStudent = true; // Boolean
let marks = 100; // Null
let city="Vadodara"; // Undefined

console.log(name, age, isStudent, marks, city);

let x = 10, y = 5;
console.log("Sum:", x + y);
console.log("Difference:", x - y);
console.log("Product:", x * y);
console.log("Quotient:", x / y);
console.log("Remainder:", x % y);
