console.log("Hello, JavaScript!");
console.log("This is a test log to check if Node is working.");
