function checkEvenOdd(number) {
    if (number % 2 === 0) {
        console.log(number + " is even");
    } else {
        console.log(number + " is odd");
    }
}
checkEvenOdd(10);
checkEvenOdd(7);

function findLargest(a, b, c) {
    if (a > b && a > c) {
        console.log(a + " is the largest");
    } else if (b > c) {
        console.log(b + " is the largest");
    } else {
        console.log(c + " is the largest");
    }
}
findLargest(45, 78, 12);
